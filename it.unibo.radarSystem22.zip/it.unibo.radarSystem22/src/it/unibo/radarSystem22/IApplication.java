package it.unibo.radarSystem22;

public interface IApplication {
	public void doJob( String domainConfig, String systemConfig );
	public String getName();
}
