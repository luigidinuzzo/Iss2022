package it.unibo.radarSystem22.sprint3.interpreters;
 
public interface IApplInterpreter {
 	public String elaborate( String message );
}
